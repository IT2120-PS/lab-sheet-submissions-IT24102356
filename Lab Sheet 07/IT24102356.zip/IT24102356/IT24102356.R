setwd("/Users/praveenherath/Desktop/IT24102356")
getwd()


#Question 01
punif(25,min=0,max=40,lower.tail = TRUE)-punif(10,min=0,max=40,lower.tail = TRUE)


#Question 02
pexp(2,rate = 0.3333,lower.tail = TRUE)

#Question 03

#a
pnorm(130,mean=100,sd=15,lower.tail = FALSE)

#b
qnorm(0.95,mean=100,sd=15,lower.tail = TRUE)
