setwd("/Users/praveenherath/Desktop/IT24102356")
getwd()


data<-read.table("Exercise - LaptopsWeights.txt", header = TRUE)
fix(data)
attach(data)

#01
#Calculate the population mean and population standard deviation of the laptop
#bag weights

popmn<-mean( Weight.kg.)
print(popmn)

popsd<-sd( Weight.kg.)
print(popsd)

popvar<-var( Weight.kg.)
print(popvar)

#02
#Draw 25 random samples of size 6 (with replacement) and calculate the sample
#mean and sample standard deviation for each sample.

samples<- c()
n<- c()

for(i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  samples<-cbind(samples,5)
  n<-c(n,paste('s',i))
}

colnames(samples) =n

s.means<-apply(samples,2,mean)
s.sds<-apply(samples,2,sd)

print(s.means)
print(s.sds)

#03
#Calculate the mean and standard deviation of the 25 sample means and state the
#relationship of them with true mean and true standard deviation.

samplemean <- mean(s.means)
samplesd<-sd(s.means)

print(samplemean)
print(samplesd)