setwd("/Users/praveenherath/Desktop/IT24102356")
getwd()

data<-read.table("Data - Lab 8.txt",header = TRUE)
fix(data)
attach(data)

popmn<-mean(Nicotine)
popvar<-var(Nicotine)

popmn
popvar

samples<-c()
n<-c()

for(i in 1:30){
  S<-sample(Nicotine,5,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}

colnames(samples)=n

s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)

s.means
s.vars


samplemean<-mean(s.means)
samplevars<-var(s.means)

samplemean
samplevars




popmn
samplemean

#Population mean = true population mean (average of the whole dataset).


#Sample mean = you must have taken a sample from that datasetand 
#calculated its meanwhich is usually different from the population
#mean unless you happened to pick all values or a very representative set.


truevar = popvar/5
samplevars
truevar

#truevar is the variance of the whole population (all nicotine values),
#That’s the true population variance,

#samplevars is the variance of sample,That means that, in the sample 
#you selected, all the values were the same (or nearly the same), 
#so the variance is 0.
