setwd("/Users/praveenherath/Desktop/IT24102356")

## 1 ##

branch_data<-read.table("Exercise.txt",header=TRUE,sep=",")
fix(branch_data)

attach(branch_data)

## 2 ##

str(branch_data)

#Branch<-Integer(Nominal(this scale categorizes data without any inherent order or ranking))
#Sales_X1<-Numeric(Ratio(properties of interval scales,plus a true point))
#Advertising_X2<-Numeric(ratio)
#Years_X3<-Integer(Ratio)



## 3 ##
boxplot(branch_data$Sales_X1,main ="Boxplot for sales",outline = TRUE,outpch=8,horizontal=TRUE)


## 4 ##

#Five number summary
summary(Advertising_X2)

#obtaining IQR
IQR(Advertising_X2)


## 5 ##


get.outliers <- function(z) {
  q1<-quantile(z,0.25)
  q3<-quantile(z,0.75)
  iqr <- q3 - q1        
  
  ub <- q3 + 1.5 * iqr      
  lb <- q1 - 1.5 * iqr     
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  
  outliers <- z[z < lb | z > ub]
  if (length(outliers) == 0) {
    print("No outliers found")
  } else {
    print(paste("Outliers: ", paste(sort(outliers), collapse = " , ")))
  }
}


get.outliers(branch_data$Years_X3) 


