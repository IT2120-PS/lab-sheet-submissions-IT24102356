setwd("/Users/praveenherath/Desktop/IT24102356")
getwd()

observed <- c(30, 20, 25, 25) 
expected_prob <- c(0.25, 0.25, 0.25, 0.25)


chi_test <- chisq.test(observed, p = expected_prob)
print(chi_test)



if(chi_test$p.value < 0.05){
  cat("\nConclusion: Reject H0. Customers do NOT choose snacks equally.\n")
} else {
  cat("\nConclusion: Fail to reject H0. No evidence against equal choice.\n")
}